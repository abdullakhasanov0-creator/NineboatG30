package com.example.g30kcq

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: MainViewModel) {
    val ui by vm.ui.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("G30 · KCQ") },
                actions = {
                    Box {
                        IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Меню") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            DropdownMenuItem(text = { Text("Настройки") }, onClick = { menu = false; dialog = "settings" })
                            DropdownMenuItem(text = { Text("Прошивка") }, onClick = { menu = false; dialog = "firmware" })
                        }
                    }
                },
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = {}, label = { Text("Управление") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = {}, label = { Text("Диагностика") })
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 0) ControlScreen(vm, ui) else DiagScreen(vm, ui)
        }
    }

    if (dialog == "firmware") {
        AlertDialog(
            onDismissRequest = { dialog = "" },
            confirmButton = { TextButton(onClick = { dialog = "" }) { Text("Закрыть") } },
            title = { Text("Прошивка") },
            text = { Text("Не реализовано (намеренно). Команд прошивки в APK оригинала не искал и не использовал.") },
        )
    }
    if (dialog == "settings") SettingsDialog(vm, ui) { dialog = "" }
}

@Composable
fun SettingsDialog(vm: MainViewModel, ui: UiState, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = { TextButton(onClick = onClose) { Text("Закрыть") } },
        title = { Text("Настройки") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Тема", style = MaterialTheme.typography.titleSmall)
                listOf(ThemeMode.SYSTEM to "Системная", ThemeMode.LIGHT to "Светлая", ThemeMode.DARK to "Тёмная").forEach { (m, name) ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = ui.theme == m, onClick = { vm.setTheme(m) })
                        Text(name)
                    }
                }
                val st = ui.status
                Text("Режимы контроллера", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 8.dp))
                if (st == null) {
                    Text("Нет данных от контроллера")
                } else {
                    val s = st.setting
                    ModeRow("Круиз (cruise)", s.cruise) { vm.setMode(Protocol.W_CRUISE, it, "Круиз") }
                    ModeRow("Режим старта (startMode)", s.startMode) { vm.setMode(Protocol.W_START, it, "Режим старта") }
                    ModeRow("Мили (unit)", s.unitMiles) { vm.setMode(Protocol.W_UNIT, it, "Мили") }
                    if (!Config.ALLOW_WRITE) Text("Запись выключена: только журнал", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
    )
}

@Composable
fun ModeRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(title)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun ControlScreen(vm: MainViewModel, ui: UiState) {
    val perms = if (Build.VERSION.SDK_INT >= 31) {
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    } else {
        arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) vm.startScan() else vm.say("Нет разрешений Bluetooth")
    }
    val st = ui.status
    val ready = ui.conn == ConnState.READY && st != null

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (!Config.ALLOW_WRITE) {
            Card(Modifier.fillMaxWidth()) {
                Text(
                    "Запись выключена (ALLOW_WRITE=false). Кнопки только формируют кадры в журнале (TX-DRY).",
                    Modifier.padding(12.dp),
                )
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    when (ui.conn) {
                        ConnState.DISCONNECTED -> "Не подключено"
                        ConnState.CONNECTING -> "Подключение…"
                        ConnState.READY -> "Подключено: ${ui.connAddress}"
                    },
                    style = MaterialTheme.typography.titleMedium,
                )
                if (ui.conn == ConnState.DISCONNECTED) {
                    Button(onClick = { launcher.launch(perms) }) { Text(if (ui.scanning) "Сканирую…" else "Сканировать") }
                    ui.found.forEach { d ->
                        TextButton(onClick = { vm.connect(d.address) }) {
                            Text("${d.name ?: "—"}  ${d.address}  ${d.rssi} dBm" + if (d.hasService) "  ★FFF0" else "")
                        }
                    }
                } else {
                    OutlinedButton(onClick = { vm.disconnect() }) { Text("Отключить") }
                }
            }
        }

        if (st != null) {
            Card(Modifier.fillMaxWidth()) {
                Text(
                    "Скорость ${"%.1f".format(st.speedKmh)} км/ч · Батарея ${st.battery}% · Передача ${st.setting.gear}",
                    Modifier.padding(12.dp),
                    style = MaterialTheme.typography.titleMedium,
                )
            }
        }

        val s = st?.setting
        StateButton("Передний фонарь", s?.headlight == true, ready) { vm.setFront(it) }
        StateButton("Задний фонарь", s?.taillight == true, ready) { vm.setRear(it) }
        StateButton("Блокировка колеса", s?.lock == true, ready) { vm.setLock(it) }

        Text("Передача", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            for (g in 1..3) {
                val sel = s?.gear == g
                val enabled = ready && (g < 3 || st?.thirdGearView == true)
                if (sel) Button(onClick = { vm.setGear(g) }, enabled = enabled) { Text("$g") }
                else OutlinedButton(onClick = { vm.setGear(g) }, enabled = enabled) { Text("$g") }
            }
        }

        Text("Скорость по передачам (максимум ${Config.MAX_SPEED_KMH} км/ч)", style = MaterialTheme.typography.titleMedium)
        val p = ui.ped
        val b = ui.bounds
        if (p != null && b != null && st != null) {
            SpeedRow("Передача 1", p.one, b.range(1), ready && !st.cycling) { vm.applySpeed(1, it) }
            SpeedRow("Передача 2", p.two, b.range(2), ready && !st.cycling) { vm.applySpeed(2, it) }
            SpeedRow("Передача 3", p.three, b.range(3), ready && !st.cycling) { vm.applySpeed(3, it) }
        } else {
            Text("Жду кадры AA 56 / AA 57 от контроллера…")
        }

        ui.message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun StateButton(title: String, on: Boolean, enabled: Boolean, onToggle: (Boolean) -> Unit) {
    val text = "$title: ${if (on) "ВКЛ" else "выкл"}"
    if (on) Button(onClick = { onToggle(false) }, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text(text) }
    else OutlinedButton(onClick = { onToggle(true) }, enabled = enabled, modifier = Modifier.fillMaxWidth()) { Text(text) }
}

@Composable
fun SpeedRow(title: String, cur: Int, range: Pair<Int, Int>, enabled: Boolean, onApply: (Int) -> Unit) {
    val lo = range.first
    val top = minOf(range.second, Config.MAX_SPEED_KMH)
    if (top <= lo) {
        Text("$title: диапазон контроллера ${range.first}–${range.second}, менять нельзя")
        return
    }
    var v by remember(cur) { mutableFloatStateOf(cur.coerceIn(lo, top).toFloat()) }
    Column {
        Text("$title: ${v.roundToInt()} км/ч (сейчас $cur; допустимо $lo–$top)")
        Slider(value = v, onValueChange = { v = it }, valueRange = lo.toFloat()..top.toFloat(), steps = top - lo - 1, enabled = enabled)
        Button(onClick = { onApply(v.roundToInt()) }, enabled = enabled) { Text("Применить") }
    }
}

@Composable
fun DiagScreen(vm: MainViewModel, ui: UiState) {
    val ctx = LocalContext.current
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) vm.export(uri)
    }
    val appVer = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "?" }
    val st = ui.status

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item { Text("Версии", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp)) }
        item { Text("Приложение: $appVer") }
        item { Text("Версия прошивки контроллера: в кадрах оригинала не найдена; ниже — стандартные GATT-чтения, если есть.") }
        if (ui.info.isEmpty()) item { Text("Нет данных чтения (нужно подключение)") }
        ui.info.forEach { (k, v) -> item { Text("$k: $v", fontFamily = FontFamily.Monospace, fontSize = 12.sp) } }

        item { Text("Батарея и пробег", style = MaterialTheme.typography.titleMedium) }
        if (st == null) item { Text("Нет данных") } else {
            item { Text("Батарея: ${st.battery}%") }
            item { Text("Пробег поездки: ${"%.1f".format(st.tripRaw / 10.0)} · общий: ${"%.1f".format(st.totalRaw / 10.0)} (raw/10, единицы по декомпиляции)") }
            item { Text("Время в пути (raw): ${st.rideSeconds}") }
        }

        item { Text("Ошибки", style = MaterialTheme.typography.titleMedium) }
        if (st == null) item { Text("Нет данных") }
        else if (st.faults.isEmpty()) item { Text("Нет") }
        else st.faults.forEach { f -> item { Text("• $f") } }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                Button(onClick = { export.launch("g30_log.txt") }) { Text("Экспорт .txt") }
                OutlinedButton(onClick = { vm.clearLog() }) { Text("Очистить") }
            }
        }
        item { Text("Журнал пакетов (hex, новые сверху)", style = MaterialTheme.typography.titleMedium) }
        items(ui.log.asReversed()) { line -> Text(line, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
    }
}
