package com.example.g30kcq

object Config {
    /**
     * Запись в контроллер. false = «сухой прогон»: кадры строятся и пишутся в журнал (TX-DRY),
     * но в BLE не отправляются. Включать только осознанно и на стоящем самокате.
     */
    const val ALLOW_WRITE: Boolean = true

    /**
     * Скорость, передачи и режимы (круиз/старт/мили). false = только журнал TX-DRY.
     * Фонари и блокировка работают при ALLOW_WRITE = true. Байты не проверены по APK.
     */
    const val ALLOW_SPEED_MODES: Boolean = false

    /** Жёсткий потолок скорости передачи, км/ч (дополнительно ограничен диапазоном, который сообщает контроллер). */
    const val MAX_SPEED_KMH: Int = 50

    /** Оригинал шлёт кадр скорости 3 раза подряд (цикл i<3 в SpeedSettingActivity). */
    const val SPEED_FRAME_REPEAT: Int = 3
}
