package com.example.g30kcq

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class ThemeMode { SYSTEM, LIGHT, DARK }

data class UiState(
    val theme: ThemeMode = ThemeMode.SYSTEM,
    val scanning: Boolean = false,
    val found: List<Found> = emptyList(),
    val conn: ConnState = ConnState.DISCONNECTED,
    val connAddress: String? = null,
    val status: Protocol.Status? = null,
    val ped: Protocol.Ped? = null,
    val bounds: Protocol.Bounds? = null,
    val info: Map<String, String> = emptyMap(),
    val log: List<String> = emptyList(),
    val message: String? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app), BleClient.Listener {

    private val prefs = app.getSharedPreferences("g30", Context.MODE_PRIVATE)
    private val _ui = MutableStateFlow(UiState(theme = loadTheme()))
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private val ble = BleClient(app, this)
    private val lines = ArrayDeque<String>()
    private val lastRx = HashMap<Int, ByteArray>()
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    private fun loadTheme(): ThemeMode =
        try { ThemeMode.valueOf(prefs.getString("theme", "SYSTEM") ?: "SYSTEM") } catch (e: Exception) { ThemeMode.SYSTEM }

    fun setTheme(m: ThemeMode) {
        prefs.edit().putString("theme", m.name).apply()
        _ui.update { it.copy(theme = m) }
    }

    fun say(text: String) {
        _ui.update { it.copy(message = text) }
        log("INFO", text)
    }

    private fun log(dir: String, text: String) {
        lines.addLast("${fmt.format(Date())} $dir $text")
        while (lines.size > 500) lines.removeFirst()
        _ui.update { it.copy(log = lines.toList()) }
    }

    fun clearLog() {
        lines.clear()
        lastRx.clear()
        _ui.update { it.copy(log = emptyList()) }
    }

    fun export(uri: Uri) {
        val st = _ui.value
        val head = buildString {
            appendLine("G30 KCQ — журнал пакетов")
            appendLine("Время: ${Date()}")
            appendLine("ALLOW_WRITE=${Config.ALLOW_WRITE}")
            appendLine("Устройство: ${st.connAddress ?: "-"}")
            st.info.forEach { (k, v) -> appendLine("$k: $v") }
            appendLine("----")
        }
        val body = lines.joinToString("\n")
        viewModelScope.launch(Dispatchers.IO) {
            try {
                getApplication<Application>().contentResolver.openOutputStream(uri)?.use {
                    it.write((head + body + "\n").toByteArray(Charsets.UTF_8))
                }
                say("Журнал сохранён")
            } catch (e: Exception) {
                say("Экспорт не удался: ${e.message}")
            }
        }
    }

    // ---------- подключение ----------
    fun startScan() = ble.startScan()
    fun connect(address: String) = ble.connect(address)
    fun disconnect() = ble.disconnect()

    // ---------- команды ----------
    private fun snap(): Protocol.Snap? {
        val st = _ui.value.status ?: return null
        val p = _ui.value.ped
        return Protocol.Snap(st.setting, st.thirdGearView, p?.view == true, p?.bit2 == true)
    }

    private fun send(label: String, frames: List<ByteArray>, allowed: Boolean = Config.ALLOW_WRITE) {
        frames.forEach { log(if (allowed) "TX  " else "TX-DRY", Protocol.hex(it) + "  [$label]") }
        if (!allowed) {
            say("Запись выключена в Config.kt: «$label» не отправлено (кадр в журнале)")
            return
        }
        if (_ui.value.conn != ConnState.READY) {
            say("Нет подключения")
            return
        }
        ble.write(frames)
        say("Отправлено: $label")
    }

    private fun cmd(label: String, allowed: Boolean = Config.ALLOW_WRITE, build: (Protocol.Snap) -> ByteArray) {
        val s = snap() ?: run {
            say("Нет состояния контроллера (жду кадр AA 55)")
            return
        }
        send(label, listOf(build(s)), allowed)
    }

    private fun onOff(on: Boolean) = if (on) "вкл" else "выкл"

    fun setFront(on: Boolean) = cmd("Передний фонарь ${onOff(on)}") { Protocol.bitCommand(it, Protocol.W_HEAD, on) }
    fun setRear(on: Boolean) = cmd("Задний фонарь ${onOff(on)}") { Protocol.bitCommand(it, Protocol.W_TAIL, on) }

    fun setLock(on: Boolean) {
        val st = _ui.value.status
        if (on && st != null && st.speedRaw > 0) {
            say("Колесо на ходу не блокирую")
            return
        }
        cmd("Блокировка колеса ${onOff(on)}") { Protocol.bitCommand(it, Protocol.W_LOCK, on) }
    }

    fun setMode(bit: Int, on: Boolean, name: String) = cmd("$name ${onOff(on)}", Config.ALLOW_WRITE && Config.ALLOW_SPEED_MODES) { Protocol.bitCommand(it, bit, on) }

    fun setGear(g: Int) = when (g) {
        1 -> cmd("Передача 1", Config.ALLOW_WRITE && Config.ALLOW_SPEED_MODES) { Protocol.gear1(it) }
        2 -> cmd("Передача 2", Config.ALLOW_WRITE && Config.ALLOW_SPEED_MODES) { Protocol.gear2(it) }
        else -> {
            if (_ui.value.status?.thirdGearView == true) cmd("Передача 3", Config.ALLOW_WRITE && Config.ALLOW_SPEED_MODES) { Protocol.gear3(it) }
            else say("Контроллер не сообщает 3-ю передачу (thirdGear)")
        }
    }

    /** Скорость передачи, км/ч: A7 (1-я и 2-я) или A8 (3-я). Потолок = min(50, предел контроллера). */
    fun applySpeed(gear: Int, kmh: Int) {
        val ui = _ui.value
        val p = ui.ped
        val b = ui.bounds
        val st = ui.status
        if (p == null || b == null || st == null) {
            say("Нет данных о скоростях (кадры AA 56 / AA 57)")
            return
        }
        if (st.cycling) {
            say("Самокат в движении — скорость не меняю (как в оригинале)")
            return
        }
        val cur = when (gear) { 1 -> p.one; 2 -> p.two; else -> p.three }
        if (cur == 0) {
            say("Текущая скорость передачи неизвестна")
            return
        }
        val (lo, hi) = b.range(gear)
        val top = minOf(Config.MAX_SPEED_KMH, hi)
        if (kmh < lo || kmh > top) {
            say("Допустимо $lo–$top км/ч")
            return
        }
        val frame = when (gear) {
            1 -> Protocol.speed12(kmh, p.two)
            2 -> Protocol.speed12(p.one, kmh)
            else -> Protocol.speed3(kmh, p.start, p.three)
        }
        send("Скорость передачи $gear = $kmh км/ч", List(Config.SPEED_FRAME_REPEAT) { frame }, Config.ALLOW_WRITE && Config.ALLOW_SPEED_MODES)
    }

    // ---------- BleClient.Listener ----------
    override fun onScan(list: List<Found>) { _ui.update { it.copy(found = list) } }
    override fun onScanning(on: Boolean) { _ui.update { it.copy(scanning = on) } }

    override fun onConn(s: ConnState, address: String?) {
        _ui.update {
            if (s == ConnState.READY) it.copy(conn = s, connAddress = address)
            else it.copy(conn = s, connAddress = address, status = null, ped = null, bounds = null)
        }
        log("CONN", "$s ${address ?: ""}")
    }

    override fun onRx(data: ByteArray) {
        val type = if (data.size > 1) data[1].toInt() and 0xFF else -1
        val prev = lastRx[type]
        if (prev == null || !prev.contentEquals(data)) {
            lastRx[type] = data
            log("RX  ", Protocol.hex(data))
        }
        if (data.isEmpty() || (data[0].toInt() and 0xFF) != 0xAA) return
        when (type) {
            0x55 -> Protocol.parseStatus(data)?.let { s -> _ui.update { it.copy(status = s) } }
            0x56 -> Protocol.parsePed(data)?.let { s -> _ui.update { it.copy(ped = s) } }
            0x57 -> Protocol.parseBounds(data)?.let { s -> _ui.update { it.copy(bounds = s) } }
            else -> Unit
        }
    }

    override fun onInfo(name: String, data: ByteArray) {
        val hex = Protocol.hex(data)
        val text = if (data.isNotEmpty() && data.all { it.toInt() in 32..126 }) "${String(data, Charsets.US_ASCII)}  [$hex]" else hex
        _ui.update { it.copy(info = it.info + (name to text)) }
        log("READ", "$name = $hex")
    }

    override fun onTx(data: ByteArray) = log("TX  ", Protocol.hex(data) + "  (записано в FFF6)")
    override fun onNote(text: String) = log("NOTE", text)
}
