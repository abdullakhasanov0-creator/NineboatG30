package com.example.g30kcq

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Ожидаемые значения посчитаны зеркалом алгоритма RequestPackage (AA CC SIG b1 b2 b1^SIG sum EE). */
class ProtocolTest {
    private fun snap(settingByte: Int, thirdView: Boolean = false) =
        Protocol.Snap(Protocol.parseSetting(settingByte), thirdView, pedView = false, pedBit2 = false)

    @Test fun frameLayoutAndChecksums() {
        assertEquals("AA CC A5 08 00 AD 5A EE", Protocol.hex(Protocol.frame(0xA5, 0x08, 0x00)))
    }

    @Test fun headlightOnFromGear1() {
        assertEquals("AA CC A5 08 00 AD 5A EE", Protocol.hex(Protocol.bitCommand(snap(0x01), Protocol.W_HEAD, true)))
    }

    @Test fun taillightOnFromGear1() {
        assertEquals("AA CC A5 10 00 B5 6A EE", Protocol.hex(Protocol.bitCommand(snap(0x01), Protocol.W_TAIL, true)))
    }

    @Test fun lockOnFromGear1() {
        assertEquals("AA CC A5 40 00 E5 CA EE", Protocol.hex(Protocol.bitCommand(snap(0x01), Protocol.W_LOCK, true)))
    }

    @Test fun headlightOnFromGear2KeepsGearBit() {
        assertEquals("AA CC A5 09 00 AC 5A EE", Protocol.hex(Protocol.bitCommand(snap(0x02), Protocol.W_HEAD, true)))
    }

    @Test fun gear3() {
        assertEquals("AA CC A5 01 20 A4 4A EE", Protocol.hex(Protocol.gear3(snap(0x01))))
        assertEquals("AA CC A5 01 30 A4 4A EE", Protocol.hex(Protocol.gear3(snap(0x01, thirdView = true))))
    }

    @Test fun speedFrames() {
        assertEquals("AA CC A7 0F 19 A8 5E EE", Protocol.hex(Protocol.speed12(15, 25)))
        assertEquals("AA CC A8 1E 08 B6 7C EE", Protocol.hex(Protocol.speed3(30, 8, 30)))
    }

    @Test fun parseSettingGears() {
        assertEquals(1, Protocol.parseSetting(0x01).gear)
        assertEquals(2, Protocol.parseSetting(0x02).gear)
        assertEquals(3, Protocol.parseSetting(0x03).gear)
        assertTrue(Protocol.parseSetting(0x01).gearFlag)
        assertFalse(Protocol.parseSetting(0x03).gearFlag)
        assertTrue(Protocol.parseSetting(0x10).headlight)
        assertTrue(Protocol.parseSetting(0x20).taillight)
        assertTrue(Protocol.parseSetting(0x80).lock)
    }

    @Test fun parseStatusFrame() {
        val f = ByteArray(16)
        f[0] = 0xAA.toByte(); f[1] = 0x55; f[2] = 0x2C; f[3] = 0x01   // 0x012C = 300 -> 30.0 км/ч
        f[8] = 87; f[11] = 0x11
        val s = Protocol.parseStatus(f)!!
        assertEquals(30.0, s.speedKmh, 0.001)
        assertEquals(87, s.battery)
        assertTrue(s.setting.headlight)
        assertEquals(1, s.setting.gear)
        assertNull(Protocol.parseStatus(ByteArray(4)))
    }

    @Test fun effectiveGearPedestrian() {
        assertEquals(0, Protocol.effectiveGear(2, pedView = true, pedBit2 = true))
        assertEquals(1, Protocol.effectiveGear(2, pedView = true, pedBit2 = false))
        assertEquals(3, Protocol.effectiveGear(3, pedView = true, pedBit2 = false))
        assertEquals(2, Protocol.effectiveGear(2, pedView = false, pedBit2 = false))
    }
}
